# BC Legal AI — Hugging Face Release

This release has two independent deployment targets.

## 1. Model repository

Target: `Dmang69/bc-legal-ai-base`

Use the files under `model-repair/` to replace the invalid
`bc_legal_ai_policy_card` repository with the complete
`Qwen/Qwen2.5-7B-Instruct` runtime assets.

## 2. Gradio Space

Target: `Dmang69/bc-legal-ai`

The `space/` folder contains exactly:

- `app.py`
- `README.md`
- `requirements.txt`

Run:

```bash
python verify_release.py
```

Then set a write token only in the environment:

```bash
export HF_TOKEN=hf_...
python deploy_space.py
```

On Windows PowerShell:

```powershell
$env:HF_TOKEN = "hf_..."
python deploy_space.py
```

Never commit the token.

## Safety posture

The public Space is synthetic-only, contains no upload control, calls no external
model, stores no matters, and reports `court_ready=false`.
