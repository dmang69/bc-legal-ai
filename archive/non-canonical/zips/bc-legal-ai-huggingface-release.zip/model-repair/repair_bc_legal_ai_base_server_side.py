# Repair Dmang69/bc-legal-ai-base using Hugging Face server-side repository copying.
# Run in Colab/Jupyter. The token is prompted securely and is never written into this file.

import sys
import subprocess
from datetime import datetime, timezone

subprocess.check_call([
    sys.executable, "-m", "pip", "install", "-U",
    "huggingface_hub>=1.4.0",
    "transformers>=4.55.0",
    "accelerate>=1.10.0",
    "safetensors>=0.6.0",
])

from huggingface_hub import HfApi, copy_files, login
from transformers import AutoConfig, AutoTokenizer

SOURCE_REPO = "Qwen/Qwen2.5-7B-Instruct"
TARGET_REPO = "Dmang69/bc-legal-ai-base"
BACKUP_BRANCH = "broken-policy-card-backup-20260722"

# Prompts for a Hugging Face write token.
login(add_to_git_credential=False)

api = HfApi()

# Confirm that the authenticated account has access to both repositories.
source_info = api.model_info(SOURCE_REPO)
target_info = api.model_info(TARGET_REPO)
print("Source:", source_info.id)
print("Target:", target_info.id)

# Preserve the current broken repository state before changing main.
try:
    api.create_branch(
        repo_id=TARGET_REPO,
        branch=BACKUP_BRANCH,
        repo_type="model",
        exist_ok=True,
    )
    print("Backup branch ready:", BACKUP_BRANCH)
except TypeError:
    # Compatibility fallback for huggingface_hub versions without exist_ok.
    try:
        api.create_branch(
            repo_id=TARGET_REPO,
            branch=BACKUP_BRANCH,
            repo_type="model",
        )
        print("Backup branch created:", BACKUP_BRANCH)
    except Exception as exc:
        if "already exists" not in str(exc).lower():
            raise
        print("Backup branch already exists:", BACKUP_BRANCH)

# Copy every source file server-side. The trailing slash copies the repository
# contents into the target root. Large Xet/LFS weights are copied by hash.
copy_files(
    f"hf://{SOURCE_REPO}/",
    f"hf://{TARGET_REPO}/",
)
print("Qwen runtime assets copied.")

# Replace the upstream README with accurate BC Legal AI provenance.
model_card = f"""---
library_name: transformers
pipeline_tag: text-generation
license: apache-2.0
base_model: {SOURCE_REPO}
tags:
  - qwen2
  - text-generation
  - legal
  - british-columbia
  - not-legal-advice
---

# BC Legal AI Base

This repository is a **loadable development base checkpoint** mirrored from
[`{SOURCE_REPO}`](https://huggingface.co/{SOURCE_REPO}).

The neural weights are the unmodified Qwen base weights. They are **not yet a
BC-law fine-tune**. Legal controls belong in the application and retrieval layer:

- official BC source retrieval;
- current and point-in-time legislative verification;
- evidence and citation provenance;
- privilege, consent, and export gates;
- human/lawyer approval;
- `court_ready: false` unless every production gate passes.

## Load

```python
from transformers import AutoModelForCausalLM, AutoTokenizer

model_id = "{TARGET_REPO}"
tokenizer = AutoTokenizer.from_pretrained(model_id)
model = AutoModelForCausalLM.from_pretrained(
    model_id,
    device_map="auto",
    torch_dtype="auto",
)
```

This model is not a lawyer and does not provide legal advice. Public
demonstrations must remain synthetic-only.

Project source: https://github.com/dmang69/bc-legal-ai
"""

api.upload_file(
    path_or_fileobj=model_card.encode("utf-8"),
    path_in_repo="README.md",
    repo_id=TARGET_REPO,
    repo_type="model",
    commit_message="Correct model architecture and provenance",
)

# Remove stale files that are not part of the genuine Qwen repository.
source_files = set(api.list_repo_files(SOURCE_REPO, repo_type="model"))
target_files = set(api.list_repo_files(TARGET_REPO, repo_type="model"))
allowed_project_files = {"README.md", ".gitattributes"}
obsolete_files = sorted(target_files - source_files - allowed_project_files)

for filename in obsolete_files:
    api.delete_file(
        path_in_repo=filename,
        repo_id=TARGET_REPO,
        repo_type="model",
        commit_message=f"Remove obsolete unsupported artifact: {filename}",
    )
    print("Removed obsolete file:", filename)

# Validate the remote repository without loading all 7B weights.
config = AutoConfig.from_pretrained(TARGET_REPO, force_download=True)
tokenizer = AutoTokenizer.from_pretrained(TARGET_REPO, force_download=True)

assert config.model_type != "bc_legal_ai_policy_card", config.model_type
assert tokenizer is not None

print("\nREPAIR VERIFIED")
print("model_type:", config.model_type)
print("architectures:", config.architectures)
print("tokenizer:", type(tokenizer).__name__)
print("target:", TARGET_REPO)
print("backup branch:", BACKUP_BRANCH)
print("verified_at:", datetime.now(timezone.utc).isoformat())
