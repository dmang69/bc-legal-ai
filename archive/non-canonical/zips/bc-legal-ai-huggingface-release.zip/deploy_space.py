"""Upload the corrected Space folder to Hugging Face."""
from __future__ import annotations
import os
from huggingface_hub import HfApi

TOKEN = os.environ.get("HF_TOKEN")
if not TOKEN:
    raise SystemExit("Set HF_TOKEN to a Hugging Face write token.")

api = HfApi(token=TOKEN)
api.create_repo(
    repo_id="Dmang69/bc-legal-ai",
    repo_type="space",
    space_sdk="gradio",
    exist_ok=True,
    private=False,
)
api.upload_folder(
    repo_id="Dmang69/bc-legal-ai",
    repo_type="space",
    folder_path="space",
    path_in_repo=".",
    delete_patterns=["*"],
    commit_message="Deploy corrected Gradio public demo",
)
print("Uploaded: https://huggingface.co/spaces/Dmang69/bc-legal-ai")
