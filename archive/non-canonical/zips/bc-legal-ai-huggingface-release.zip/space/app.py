"""BC Legal AI Associate — synthetic public demonstration.

No uploads, no persistent matter storage, no external model calls, and no
court-ready output. Real legal matters belong in the private supervised system.
"""
from __future__ import annotations

import os
import re
from datetime import datetime, timedelta

import gradio as gr

os.environ["APP_MODE"] = "public_demo"
APP_MODE = "public_demo"
COURT_READY = False

SENSITIVE_PATTERNS = [
    ("email address", re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.I)),
    ("telephone number", re.compile(r"(?:\+?1[-.\s]?)?(?:\(?\d{3}\)?[-.\s]?)\d{3}[-.\s]?\d{4}")),
    ("Canadian postal code", re.compile(r"\b[ABCEGHJ-NPRSTVXY]\d[ABCEGHJ-NPRSTVWXYZ][ -]?\d[ABCEGHJ-NPRSTVWXYZ]\d\b", re.I)),
    ("court-style file number", re.compile(r"\b[A-Z]{2,5}-[A-Z]-[A-Z]-\d{4,8}\b", re.I)),
    ("possible account or RTB number", re.compile(r"\b\d{8,12}\b")),
    ("civic address", re.compile(r"\b\d{1,6}\s+[A-Za-z][A-Za-z0-9.' -]{1,45}\s(?:Street|St|Road|Rd|Avenue|Ave|Drive|Dr|Lane|Ln|Place|Pl|Court|Ct|Boulevard|Blvd|Highway|Hwy)\b", re.I)),
]

OFFICIAL_SOURCES = {
    "BC Laws": "https://www.bclaws.gov.bc.ca/",
    "Residential Tenancy Branch": "https://www2.gov.bc.ca/gov/content/housing-tenancy/residential-tenancies",
    "BC Courts": "https://www.bccourts.ca/",
    "CanLII — British Columbia": "https://www.canlii.org/en/bc/",
    "BC Human Rights Tribunal": "https://www.bchrt.bc.ca/",
}

NOTICE_RULES = [
    (re.compile(r"\b(?:10|ten)[ -]?day\b|\bnon[ -]?payment\b", re.I), "Possible Ten Day Notice", "Confirm the form, service method, payment status, and current dispute window immediately."),
    (re.compile(r"\b(?:1|one)[ -]?month\b|\bfor cause\b", re.I), "Possible One Month Notice", "Confirm the form, service method, grounds, and current dispute window immediately."),
    (re.compile(r"\b(?:2|two)[ -]?month\b|\blandlord'?s use\b", re.I), "Possible Two Month Notice", "Verify the current statutory scheme, notice form, and dispute window."),
    (re.compile(r"\b(?:4|four)[ -]?month\b|\bdemolition\b|\brenovation\b|\bconversion\b", re.I), "Possible Four Month Notice", "Verify the current statutory scheme, dispute window, permits, and any right-of-first-refusal provisions."),
]

TAG_RULES = [
    ("ASSUMPTION", re.compile(r"\b(?:I think|I believe|probably|maybe|must have|I assume)\b", re.I)),
    ("ALLEGATION", re.compile(r"\b(?:allege|claims?|accuses?|they said|he said|she said)\b", re.I)),
    ("LEGAL ARGUMENT", re.compile(r"\b(?:section|s\.)\s*\d+|\b(?:Act|regulation|precedent|Vavilov|procedural fairness)\b", re.I)),
    ("RECOMMENDATION", re.compile(r"\b(?:should|recommend|next step|consider filing)\b", re.I)),
    ("FACT CANDIDATE — SOURCE REQUIRED", re.compile(r"\b\d{4}-\d{2}-\d{2}\b|\b(?:January|February|March|April|May|June|July|August|September|October|November|December)\b|\$\s?\d|\b(?:exhibit|receipt|invoice|transcript)\b", re.I)),
]

def privacy_findings(text: str) -> list[str]:
    return [name for name, pattern in SENSITIVE_PATTERNS if pattern.search(text or "")]

def source_links() -> str:
    lines = ["### Official source starting points", ""]
    lines += [f"- [{name}]({url})" for name, url in OFFICIAL_SOURCES.items()]
    lines += ["", "**Always verify current and point-in-time law before reliance.**"]
    return "\n".join(lines)

def tag_text(text: str) -> str:
    protected = re.sub(r"\b(s|e\.g|i\.e|No|Nos|vs|v|c|paras?)\.", r"\1∯", text.strip())
    sentences = [s.replace("∯", ".").strip() for s in re.split(r"(?<=[.!?])\s+|\n+", protected) if s.strip()]
    lines = ["### Analytical decomposition", ""]
    for i, sentence in enumerate(sentences, 1):
        tag = "UNCLASSIFIED — HUMAN REVIEW"
        for label, pattern in TAG_RULES:
            if pattern.search(sentence):
                tag = label
                break
        lines.append(f"{i}. **[{tag}]** {sentence}")
    lines += ["", "Every fact candidate still requires an exhibit, page, paragraph, image, or timestamp anchor."]
    return "\n".join(lines)

def triage_text(text: str) -> str:
    lines = ["### Triage", ""]
    hits = [(label, note) for pattern, label, note in NOTICE_RULES if pattern.search(text)]
    if hits:
        lines += [f"- **{label}:** {note}" for label, note in hits]
    else:
        lines.append("- No standard notice type was detected from the synthetic description.")

    low = text.lower()
    if any(x in low for x in ("judicial review", "procedural fairness", "stay", "petition", "order of possession")):
        lines.append("- **Possible forum:** BC Supreme Court judicial review. Confirm finality, the enabling statute, limitation provisions, issuance/service dates, and the required forms.")
    elif any(x in low for x in ("discrimination", "disability", "family status", "source of income")):
        lines.append("- **Possible forum:** BC Human Rights Tribunal, potentially alongside another process.")
    elif any(x in low for x in ("tenant", "landlord", "rent", "eviction", "deposit", "repair", "tenancy")):
        lines.append("- **Possible forum:** Residential Tenancy Branch.")
    else:
        lines.append("- More non-identifying facts are needed to suggest a forum.")
    return "\n".join(lines)

def jr_clock(text: str) -> str:
    if "judicial review" not in text.lower() and "jr clock" not in text.lower():
        return ""
    match = re.search(r"\b(20\d{2}-\d{2}-\d{2})\b", text)
    lines = ["### Synthetic JR date arithmetic", ""]
    if not match:
        lines.append("- Provide a synthetic issuance date in `YYYY-MM-DD` format.")
        return "\n".join(lines)
    try:
        issued = datetime.strptime(match.group(1), "%Y-%m-%d").date()
    except ValueError:
        return "### Synthetic JR date arithmetic\n\n- Invalid calendar date."
    illustrative = issued + timedelta(days=60)
    lines += [
        f"- Synthetic issuance date: **{issued.isoformat()}**",
        f"- Sixty-day arithmetic result: **{illustrative.isoformat()}**",
        "- This is not a confirmed filing deadline. Finality, governing legislation, issuance/service rules, extensions, and court holidays require human legal review.",
    ]
    return "\n".join(lines)

def respond(message: str, history: list[dict] | None, mode: str, specialist: str):
    history = list(history or [])
    text = (message or "").strip()
    if not text:
        return "", history

    findings = privacy_findings(text)
    if findings:
        response = (
            "## Input blocked by the public-demo privacy gate\n\n"
            f"The message appears to contain: **{', '.join(sorted(set(findings)))}**. "
            "The matched content was not repeated. Replace it with fictional placeholders.\n\n"
            f"`app_mode={APP_MODE}` · `court_ready={str(COURT_READY).lower()}`"
        )
    else:
        parts = [f"## {specialist}", f"**Mode:** {mode}", ""]
        if mode == "Evidence analysis" or any(x in text.lower() for x in ("evidence", "allegation", "assumption", "contradiction", "tag")):
            parts.append(tag_text(text))
        else:
            parts.append(triage_text(text))
        clock = jr_clock(text)
        if clock:
            parts += ["", clock]
        if mode == "Research navigator" or any(x in text.lower() for x in ("law", "statute", "case", "authority", "citation", "section")):
            parts += ["", source_links()]
        parts += [
            "",
            "### Required human checks",
            "- Verify current and point-in-time legislation on official sources.",
            "- Confirm service, issuance, and filing dates from the record.",
            "- Verify case existence, pinpoint support, treatment, and binding weight.",
            "- Do not file, serve, disclose, or rely on this demonstration output.",
            "",
            f"`app_mode={APP_MODE}` · `court_ready={str(COURT_READY).lower()}`",
        ]
        response = "\n".join(parts)

    history.append({"role": "user", "content": text})
    history.append({"role": "assistant", "content": response})
    return "", history

with gr.Blocks(title="BC Legal AI Associate", theme=gr.themes.Soft()) as demo:
    gr.Markdown("# ⚖️ BC Legal AI Associate")
    gr.Markdown(
        "> **Synthetic public demo — not legal advice.** No uploads, real matters, "
        "persistent storage, external model calls, or court-ready output."
    )
    with gr.Row():
        with gr.Column(scale=3):
            chatbot = gr.Chatbot(type="messages", height=520, label="Conversation")
            with gr.Row():
                mode = gr.Dropdown(
                    ["Balanced", "Matter triage", "Evidence analysis", "Research navigator"],
                    value="Balanced",
                    label="Mode",
                )
                specialist = gr.Dropdown(
                    ["BC Legal Associate", "RTB Specialist", "Evidence Analyst", "Judicial Review Guide", "Citation Clerk"],
                    value="BC Legal Associate",
                    label="Specialist",
                )
            message = gr.Textbox(
                lines=3,
                max_lines=8,
                label="Message",
                placeholder="Use fictional details only—no names, addresses, file numbers, or confidential facts.",
            )
            with gr.Row():
                send = gr.Button("Send", variant="primary")
                clear = gr.Button("Clear")
            gr.Examples(
                examples=[
                    ["A fictional tenant received a one month notice for cause. What should be checked first?", "Matter triage", "RTB Specialist"],
                    ["The landlord claims the tenant caused damage. I think the allegation is probably wrong.", "Evidence analysis", "Evidence Analyst"],
                    ["For a synthetic judicial review issued 2026-01-15, show a 60-day arithmetic illustration.", "Research navigator", "Judicial Review Guide"],
                    ["Where should I verify the current Residential Tenancy Act and case authorities?", "Research navigator", "Citation Clerk"],
                ],
                inputs=[message, mode, specialist],
            )
        with gr.Column(scale=2):
            gr.Markdown(
                """
### Public build status

- `APP_MODE=public_demo`
- Uploads disabled
- Persistent matter storage disabled
- External model calls disabled
- `court_ready=false`
- Real client use prohibited
                """
            )
            gr.Markdown(source_links())

    send.click(respond, [message, chatbot, mode, specialist], [message, chatbot])
    message.submit(respond, [message, chatbot, mode, specialist], [message, chatbot])
    clear.click(lambda: ("", []), outputs=[message, chatbot])

    gr.Markdown("Source: [dmang69/bc-legal-ai](https://github.com/dmang69/bc-legal-ai)")

if __name__ == "__main__":
    demo.queue(default_concurrency_limit=8).launch()
