---
title: BC Legal AI Associate
emoji: ⚖️
colorFrom: blue
colorTo: gray
sdk: gradio
sdk_version: 6.5.1
python_version: 3.12
app_file: app.py
pinned: false
license: apache-2.0
---

# BC Legal AI Associate

A public, synthetic-only demonstration of BC legal workflow orchestration.

## Public safety posture

- No file uploads
- No persistent matter storage
- No external model calls
- No confidential or identifying information
- No court-ready output
- Not legal advice

The demo provides synthetic matter triage, analytical tagging, official-source
navigation, and date-arithmetic illustrations. Real legal matters require the
private supervised platform, verified law, evidence provenance, privilege
controls, and human/lawyer approval.
