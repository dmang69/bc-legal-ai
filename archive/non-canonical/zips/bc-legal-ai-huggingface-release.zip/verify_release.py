"""Smoke-test the local Space bundle before upload."""
from pathlib import Path
import ast

root = Path(__file__).resolve().parent / "space"
assert (root / "app.py").exists()
assert (root / "README.md").exists()
assert (root / "requirements.txt").exists()

readme = (root / "README.md").read_text(encoding="utf-8")
requirements = (root / "requirements.txt").read_text(encoding="utf-8")
app = (root / "app.py").read_text(encoding="utf-8")

assert "sdk: gradio" in readme
assert "app_file: app.py" in readme
assert "gradio==6.5.1" in requirements
assert "APP_MODE = \"public_demo\"" in app
assert "COURT_READY = False" in app
assert "File(" not in app and "UploadButton(" not in app
ast.parse(app)

print("Space bundle smoke test passed.")
